package gov.nih.nci.cagrid.syncgts.service.globus.resource;



/** 
 * The implementation of this SyncGTSResource type.
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class SyncGTSResource extends SyncGTSResourceBase {

}
