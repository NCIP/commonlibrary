"$JAVA_HOME/bin/java" -jar pf-cda-swing.jar $*
