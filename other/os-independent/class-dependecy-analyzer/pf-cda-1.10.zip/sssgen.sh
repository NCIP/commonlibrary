"$JAVA_HOME/bin/java" -jar "./pf-sssgen.jar" -f pf-cda-swing.jar $*
chmod +x ./run.sh
