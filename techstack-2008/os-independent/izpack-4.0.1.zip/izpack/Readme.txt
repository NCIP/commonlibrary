[ IzPack 2.x-3.x - Readme ]

    > 1 - A quick introduction <
    
    IzPack 2 is a Java software installer builder released under the terms of
the Apache License Version 2.0. It is based around an installer compiler that
uses XML files to describe your installation.

    IzPack is totally independant from the Operating System which runs it. It
is also very modular so that you can easely create and integrate your own
panels (installation steps).

    The IzPack homepage is http://izpack.org/ . You can contact the
author: julien.ponge@gmail.com .

    > 2 - Licencing issues <
    
    The licences used by IzPack or the libraries it uses are available in the 
legal folder. IzPack itself is covered by the Apache License Version 2.0.
