DROP TABLE tag_item;
DROP TABLE item;
DROP TABLE product;
DROP TABLE category;
DROP TABLE Address;
DROP TABLE SellerContactInfo;
DROP TABLE id_gen;
DROP TABLE ziplocation;
DROP TABLE tag;





