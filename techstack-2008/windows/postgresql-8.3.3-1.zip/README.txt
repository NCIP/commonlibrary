NOTE! Before you run the installation, you must extract the entire
ZIP file to a temporary directory. Just double-clicking on the 
MSI files inside the ZIP will NOT work.

Before you begin, please read the installation instructions at
http://pginstaller.projects.postgresql.org
Also see the FAQ available at
http://www.postgresql.org/docs/faqs.FAQ_windows.html

The files postgresql-8.3.msi and postgresql-8.3-int.msi contain 
PostgreSQL version 8.3.3. The reason for naming the files 8.3
is because the method used to upgrade the installation does not
permit the filename to be changed.

If you install directly from the 8.3.3 MSI file, your system will
contain version 8.3.3 from the start and there is no need to
upgrade it to 8.3.3.

If you need to add or remove a feature afer you have upgraded, 
you must use the this version of the MSI file.
