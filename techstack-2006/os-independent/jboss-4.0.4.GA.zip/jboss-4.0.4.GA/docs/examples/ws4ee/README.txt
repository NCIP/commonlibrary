
Deploying the appropriate web service stack
http://wiki.jboss.org/wiki/Wiki.jsp?page=WSDeployJBossWS

Upgrading to JBossWS
http://wiki.jboss.org/wiki/Wiki.jsp?page=JBWS404Compatibility

xxxxxxxxxxxxxxxxxxxxxxx
Thomas Diesler
Web Service Lead
JBoss Inc.
xxxxxxxxxxxxxxxxxxxxxxx
